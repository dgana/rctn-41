import React, {Content, Component} from 'react';

class Awards extends Component {
    render(){
        return (
            <div className="awards" id="awards">
                <h1>Awards & Certifications</h1>
                <ul>
                    <li><i>Hack 35 1st price winner</i></li>
                    <li><i>Mentor OpenCode 19</i></li>
                    <li><i>Started Indonesia First Student and Developer Conference</i></li>
                </ul>
            </div>
        )
    }
}
export default Awards