import React, {Component} from 'react';

class Interests extends Component {
    render(){
        return (
            <div className="interests" id="interests">
                <h1>Interests</h1>
                <p>Apart from being a web developer, I spend my free time by listening to music, playing guitar, or watch movies. During the holiday, I like to travel to with my families to other places.</p>
            </div>
        )
    }
}
export default Interests;