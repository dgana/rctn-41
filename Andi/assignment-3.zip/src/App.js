import React from 'react';
import './App.css';
import {  Swapi } from './components';

function App() {
  return (
   <Swapi />
  );
}

export default App;
