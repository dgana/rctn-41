import { CURRENCY_LIST } from './constant'

const currencyList = payload => {

    return {
      type: CURRENCY_LIST,
      payload: payload.rates
    }
  }

export const getCurrencyList = () => {
 
    return dispatch => {
        fetch(`https://api.exchangeratesapi.io/latest?symbols=EUR,USD,JPY,CHF,CAD&base=IDR`)
            .then(response => response.json())
            .then(response => dispatch(currencyList(response)))
            
    }
}