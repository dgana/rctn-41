export { default as Table } from './table'
export { default as Swapi } from './swapi'