import React, { Component } from "react";
import { connect } from 'react-redux'
import { getCurrencyList } from "../../actions";

class Table extends Component {
  constructor(props) {
    super(props);
    this.state = {
        base: ''
    };
  }
  componentDidMount() {
    this.props.getCurrencyList();
  }

  //  getQuoteCurrency = (quoted) => {
  //      this.props.getCurrencyList(quoted)
  //  }

  render() {
    const { currency } = this.props
    console.log(currency)
    return (
      <>
        <h1 className={`text-center`}>Currency List to IDR</h1>
        <table className={`table table-dark table-striped text-center mx-auto `} style={{width: 500}}>
          <thead>
            <tr>
              <th>Kode</th>
              <th>We Buy</th>
              <th>Exchange Rate</th>
              <th>We Sell</th>
            </tr>
          </thead>
          <tbody>
           {currency[0] && currency.map((x,i) => (
                  <tr key={i}>
                    <td>{x[0]}</td>
                    <td>{Math.round(1/x[1])-(Math.round(1/x[1])*0.05)}</td>
                    <td>{Math.round(1/x[1])}</td>
                    <td>{Math.round(1/x[1])+(Math.round(1/x[1])*0.05)}</td>
                  </tr>
                  
                ))
              }
         </tbody>
        </table>
        <p className={`text-center`}>* base currency in IDR <br />
        API Source : https://api.exchangeratesapi.io/ <br />
        Buy & Sell with 5% spread</p>
      </>
    );
  }
}

// export default Table;

const mapStateToProps = state => {
  return {
    currency: state.currency, // { count, results }
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getCurrencyList: () => dispatch(getCurrencyList()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Table)


