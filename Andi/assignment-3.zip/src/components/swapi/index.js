import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getCurrencyList } from "../../actions";    

const Swapi = () => {
    const { currency } = useSelector(state => ({
        currency: state.currency
    }));

    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getCurrencyList());
    }, [dispatch]);

    console.log(currency)
    return (
        <>
          <h1 className={`text-center`}>Currency List to IDR</h1>
          <table className={`table table-dark table-striped text-center mx-auto `} style={{width: 500}}>
            <thead>
              <tr>
                <th>Kode</th>
                <th>We Buy</th>
                <th>Exchange Rate</th>
                <th>We Sell</th>
              </tr>
            </thead>
            <tbody>
             {currency[0] && currency.map((x,i) => (
                    <tr key={i}>
                      <td>{x[0]}</td>
                      <td>{Math.round(1/x[1])-(Math.round(1/x[1])*0.05)}</td>
                      <td>{Math.round(1/x[1])}</td>
                      <td>{Math.round(1/x[1])+(Math.round(1/x[1])*0.05)}</td>
                    </tr>
                    
                  ))
                }
           </tbody>
          </table>
          <p className={`text-center`}>* base currency in IDR <br />
          API Source : https://api.exchangeratesapi.io/ <br />
          Buy & Sell with 5% spread</p>
        </>
      );

}

export default Swapi;