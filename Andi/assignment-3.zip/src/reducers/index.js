import { combineReducers } from 'redux'

import currencyReducer from './currency'

const reducers = combineReducers({
  currency: currencyReducer
})   

export default reducers