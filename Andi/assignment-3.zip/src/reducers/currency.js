import { CURRENCY_LIST } from '../actions/constant'

const initialState = {}
    

const currencyReducer = (state = initialState, action) => {
  switch (action.type) {
    case CURRENCY_LIST:
      return Object.keys(action.payload).map((key) => [String(key), action.payload[key]]) 
    default:
      return state
  }
}

export default currencyReducer
