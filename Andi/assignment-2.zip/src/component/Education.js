import React, { Component } from 'react'
import './../App.css';

export default class Education extends Component {
  render() {
    return (
        <div className="section" >
            <h1 id="education" >Education</h1>
          
                <div>
                  <p>
                      Pendidikan vokasi , D4 Politeknik Elektronika Negeri Surabaya - ITS
                  </p>
                </div>
              
         </div>
    )
  }
}