import React, { Component } from 'react'
import './../App.css';

export default class Experience extends Component {
  render() {
    return (
        <div className="section" >
            <h1 id="experience" >Experience</h1>
          
                <div>
                  Senior IT Staff
                    <p>Tim implementasi Aplikasi CMMS untuk perusahaan : develop, training end user, helpdesk</p>
                    <p>Tim implementasi Aplikasi mobile untuk daily activity pemeliharaan</p>
                  <div> Agustus 2018-present</div>
                </div>
                <br />
                <div>
                    <h1>Junior IT Staff</h1>
                    <p>Helpdesk user  </p>
                    <p>Junior Admin jaringan</p>
                    <p>Junior Programmer</p>
                    <div> Februari 2016-Juli 2018</div>
                </div>
              
         </div>
    )
  }
}