import React, { Component } from 'react'
import './../App.css';

export default class About extends Component {
  render() {
    return (
        
            <div className="section" >
                    
                    
                    <h1 id="about" >About : andikonie@gmail.com</h1>
                    <p>Halo... Saya saat ini bekerja sebagai staff IT di salah satu anak usaha BUMN</p>
                    <p>sedang mendalami JavaScript terutama dengan library ReactJs untuk membuat aplikasi FrontEnd </p>
            </div>
    )
  }
}