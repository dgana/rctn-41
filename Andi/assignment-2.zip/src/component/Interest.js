import React, { Component } from 'react'
import './../App.css';

export default class Interest extends Component {
  render() {
    return (
        <div className="section" >
            <h1 id="interest" >Interest in</h1>
          
                <div>
                 <p>
                  Interest on gaming, coding now
                 </p>
                </div>
              
         </div>
    )
  }
}