import React, { Component } from 'react'
import './../App.css';

export default class Awards extends Component {
  render() {
    return (
        <div className="section" >
            <h1 id="awards" >Awards</h1>
          
                <div>
                  <p>
                    no big awards...
                  </p>
                </div>
              
         </div>
    )
  }
}