import React, { Component } from 'react';
import foto from './foto.png';
import './../App.css';

export default class Sidebar extends Component {
  constructor(props) {
    super(props);
    console.log(props)
    this.state = {
      listMenu: [
        {menu: "about", selected: null},
        {menu: "experience", selected: null},
        {menu: "education", selected: null},
        {menu: "skills", selected: null},
        {menu: "interest", selected: null},
        {menu: "awards", selected: null},
        
      ],
      isTop: false,
    

    }
  }
  

  componentDidMount() {
    document.addEventListener('scroll', () => {
       
          this.setState({ isTop: true })
    });
  }

  onClickItem (item) {
    this.setState({
      selected: item
    })
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll)
  }
  
  render() {
    
    
    return (
      
    <div className="sidebar-menu">
              <img className="avatar" src={foto} alt="avatar" ></img>
              <ul className="menu">
              
                 {this.state.listMenu.map((row, index) => {
                  return(
                  <li style={{'fontWeight': this.state.selected === row.menu && this.state.isTop ? 'bold' : 'normal'}} onClick={this.onClickItem.bind(this, row.menu)} key={index}><a href={`#${row.menu}`}> {row.menu} </a> </li>
                  
                  )
                })}
              </ul>
       
        </div>
    )
  } 
}