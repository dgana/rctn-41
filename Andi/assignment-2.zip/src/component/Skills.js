import React, { Component } from 'react'
import './../App.css';

export default class Skills extends Component {
  render() {
    return (
        <div className="section" >
            <h1 id="skills" >Skills</h1>
          
                <div>
                  <p>
                    Skills in helpdesk, basic programing, basic networking
                  </p>
                </div>
              
         </div>
    )
  }
}