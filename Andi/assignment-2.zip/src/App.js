import React from 'react';
import './App.css';
import Sidebar from './component/Sidebar';
import About from "./component/About";
import Experience from "./component/Experience";
import Education from './component/Education';
import Skills from './component/Skills';
import Interest from './component/Interest';
import Awards from './component/Awards';


class App extends React.Component {
  render() {
    
  return (
    <>
      <Sidebar />
    
    <div className="main">
      <About />
      <Experience />
      <Education />
      <Skills />
      <Interest />
      <Awards />
    </div>
    </>
  );
  }
}

export default App;
