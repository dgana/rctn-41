import React, { Component } from 'react';

class Interestpage extends Component {
    render(){
        return(
            <div>
                <div className="interest">               
                    <h1>INTERESTS</h1>
                    <p>blablalalabablabal</p>
                    <p>oaboboebgosbeiofbwoigboeb</p>
                </div>
            </div>
        );
    }
}

export default Interestpage;