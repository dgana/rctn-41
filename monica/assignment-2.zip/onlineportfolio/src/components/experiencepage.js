import React, { Component } from 'react';

class Experiencepage extends Component {
    render(){
        return(
            <div>
                <div className="exp">
                    <h1>EXPERIENCE</h1>
                    <div className="cols">
                        <div>
                        <h4>Github Campus Expert</h4>
                        <span>August 1 2020 - Present</span>
                        <h6>Github</h6>
                        <p>lroeihoisebgiuergiuesh</p>
                        </div>
                    </div>
                    <div className="cols">
                        <div>
                        <h4>Github Campus Expert</h4>
                        <span>August 1 2020 - Present</span>
                        <h6>Github</h6>
                        <p>lroeihoisebgiuergiuesh</p>
                        </div>
                    </div>
                    <div className="cols">
                        <div>
                        <h4>Github Campus Expert</h4>
                        <span>August 1 2020 - Present</span>
                        <h6>Github</h6>
                        <p>lroeihoisebgiuergiuesh</p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Experiencepage;