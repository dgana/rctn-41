import React, { Component } from 'react';

class Skillspage extends Component {
    render(){
        return(
            <div>
                <div className="skills-dec">
                    <h1>SKILLS</h1>
                    <h5>PROGRAMMING LANGUAGE</h5>
                    <div className="rows">
                        <div className="column">
                            <ul>
                                <li>html</li>
                                <li>python</li>
                                <li>java</li>
                                <li>javascript</li>
                            </ul>
                        </div>
                        <div className="column">
                            <ul>
                                <li>html</li>
                                <li>python</li>
                                <li>java</li>
                                <li>javascript</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Skillspage;