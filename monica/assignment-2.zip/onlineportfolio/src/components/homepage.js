import React, { Component } from 'react';

class Homepage extends Component {
    render(){
        return(
            <div className="home-font">
                <h1>Home</h1>
                <h2>This is an online profile for Monica Hartono</h2>
                <h3>Scroll down to see her information</h3>
            </div>
           
        );
    }
}

export default Homepage;