import React, { Component } from 'react';

class Awardspage extends Component {
    render(){
        return(
            <div className="awards-list">
                <h1>AWARDS & CERTIFICATION</h1>
                <ul>
                    <li>award 1</li>
                    <li>award 2</li>
                    <li>award 3</li>
                </ul>
            </div>
        );
    }
}

export default Awardspage;