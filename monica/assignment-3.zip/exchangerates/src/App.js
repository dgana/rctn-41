import React from 'react';
import './App.css';
import Rates from './Rates.js';

function App() {
  return (
    <div className="App">
      <Rates />
    </div>
  );
}

export default App;
